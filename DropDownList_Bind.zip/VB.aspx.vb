﻿Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Partial Class VB
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Dim constr As String = ConfigurationManager.ConnectionStrings("constr").ConnectionString
            Using con As New SqlConnection(constr)
                Using cmd As New SqlCommand("SELECT CustomerId, Name FROM Customers")
                    cmd.CommandType = CommandType.Text
                    cmd.Connection = con
                    con.Open()
                    ddlCustomers.DataSource = cmd.ExecuteReader()
                    ddlCustomers.DataTextField = "Name"
                    ddlCustomers.DataValueField = "CustomerId"
                    ddlCustomers.DataBind()
                    con.Close()
                End Using
            End Using
            ddlCustomers.Items.Insert(0, New ListItem("--Select Customer--", "0"))
        End If
    End Sub
End Class
