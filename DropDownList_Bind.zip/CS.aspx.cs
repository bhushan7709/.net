﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class CS : System.Web.UI.Page
{
protected void Page_Load(object sender, EventArgs e)
{
    if (!this.IsPostBack)
    {
        string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
        using (SqlConnection con = new SqlConnection(constr))
        {
            using (SqlCommand cmd = new SqlCommand("SELECT CustomerId, Name FROM Customers"))
            {
                cmd.CommandType = CommandType.Text;
                cmd.Connection = con;
                con.Open();
                ddlCustomers.DataSource = cmd.ExecuteReader();
                ddlCustomers.DataTextField = "Name";
                ddlCustomers.DataValueField = "CustomerId";
                ddlCustomers.DataBind();
                con.Close();
            }
        }
        ddlCustomers.Items.Insert(0, new ListItem("--Select Customer--", "0"));
    }
}
}