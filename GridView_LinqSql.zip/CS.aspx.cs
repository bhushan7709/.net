﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CS : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.PopulateCustomers();
        }
    }

    private void PopulateCustomers()
    {
        CustomersDataContext ctx = new CustomersDataContext();
        gvCustomers.DataSource = ctx.GetCustomers();
        gvCustomers.DataBind();
    }

    protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvCustomers.PageIndex = e.NewPageIndex;
        this.PopulateCustomers();
    }
}