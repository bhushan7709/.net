﻿
Partial Class VB
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            Me.PopulateCustomers()
        End If
    End Sub

    Private Sub PopulateCustomers()
        Dim ctx As New CustomersDataContext()
        gvCustomers.DataSource = ctx.GetCustomers()
        gvCustomers.DataBind()
    End Sub

    Protected Sub OnPageIndexChanging(sender As Object, e As GridViewPageEventArgs)
        gvCustomers.PageIndex = e.NewPageIndex
        Me.PopulateCustomers()
    End Sub
End Class
