﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    string str = "server=DESKTOP-4J4I4PC\\SQLEXPRESS; initial catalog=MCA; trusted_connection=true";
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(str);
        con.Open();
        string a="insert into Login Values('"+ TextBox1.Text+"','"+TextBox2.Text+"')";
        SqlCommand cmd = new SqlCommand(a, con);
        cmd.ExecuteNonQuery();
        TextBox1.Text = "";
        con.Close();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Label4.Text = "User's Login Information ";
        SqlConnection con = new SqlConnection(str);
        string q = "select * from Login";
        SqlDataAdapter da = new SqlDataAdapter(q, con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        GridView1.DataSource = dt;
        GridView1.DataBind();

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}